
import './App.css';

import { Header } from './componentes/header.js';


function App() {
  return (
    <div className="main-container">
    <Header/>
    </div>
  );
}

export default App;
